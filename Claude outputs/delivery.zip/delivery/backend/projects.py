import asyncio
import json
from concurrent.futures import ThreadPoolExecutor
from typing import Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status
from fastapi.responses import Response
from sqlalchemy.orm import Session

from app.database import ProjectSpec, User, get_db
from app.routers.auth import get_current_user
from app.services.project_spec_service import ProjectSpecService

router = APIRouter(prefix="/api/v1/projects", tags=["Project Specs"])

# A dedicated small pool rather than importing process.py's `executor` —
# this router has no other dependency on process.py, and keeping it
# self-contained avoids coupling two otherwise-unrelated routers together
# for no real benefit (both pools ultimately just offload a blocking
# Anthropic call from the event loop; there's no shared resource that
# needs a single pool). See project_spec_service.py's extract() docstring
# for why offloading this call is required, not optional — it's the same
# "single-process uvicorn, any un-offloaded blocking call freezes
# everyone" bug already fixed twice this session in process.py.
executor = ThreadPoolExecutor(max_workers=2)
spec_service = ProjectSpecService()


@router.post("/extract")
async def extract_project_spec(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
):
    """Runs the uploaded PTS/spec document through ProjectSpecService and
    returns the structured digest directly — NOT auto-saved. The frontend
    shows it immediately and offers a separate "Save" action (POST
    /save below) if the engineer wants to keep it, mirroring the
    Analyze-then-"Save to Archive" pattern the rest of the app already
    uses rather than persisting every attempt automatically."""
    if not file.filename or not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="لازم ترفع ملف PDF.")

    contents = await file.read()
    if not contents:
        raise HTTPException(status_code=400, detail="الملف فاضي أو مش قادر أقرأه.")

    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(executor, spec_service.extract, contents)

    return {"filename": file.filename, "data": result}


@router.post("/match-rooms")
async def match_project_rooms(
    digest: str = Form(...),  # JSON string — the digest from /extract or a saved ProjectSpec
    drawing_file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
):
    """Trial step 2 (per the user's explicit request): given a digest
    already extracted from the project's PTS, plus an actual drawing PDF,
    identify every room/area on the drawing and state what the digest
    requires for each one. Deliberately NOT persisted anywhere yet — this
    is an initial trial of one step in a larger planned pipeline, not a
    finished feature with its own storage model. The frontend just shows
    the result inline for review."""
    try:
        parsed_digest = json.loads(digest)
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="بيانات الخلاصة الفنية غير صالحة.")

    if not drawing_file.filename or not drawing_file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="لازم ترفع ملف PDF للمخطط.")

    drawing_bytes = await drawing_file.read()
    if not drawing_bytes:
        raise HTTPException(status_code=400, detail="ملف المخطط فاضي أو مش قادر أقرأه.")

    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(
        executor, spec_service.match_rooms, parsed_digest, drawing_bytes
    )

    return {"filename": drawing_file.filename, "data": result}


@router.post("/save")
async def save_project_spec(
    filename: str = Form(...),
    data: str = Form(...),  # JSON string — the digest returned by /extract
    file: Optional[UploadFile] = File(None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    try:
        parsed_data = json.loads(data)
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="بيانات الاستخراج غير صالحة.")

    pdf_content = await file.read() if file else None

    spec = ProjectSpec(
        user_id=current_user.id,
        filename=filename,
        pdf_bytes=pdf_content,
        extracted_data=parsed_data,
    )
    db.add(spec)
    db.commit()
    db.refresh(spec)
    return {"status": "success", "id": spec.id}


@router.get("/my-specs")
async def list_project_specs(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    specs = (
        db.query(ProjectSpec)
        .filter(ProjectSpec.user_id == current_user.id)
        .order_by(ProjectSpec.created_at.desc())
        .all()
    )
    return [
        {
            "id": s.id,
            "filename": s.filename,
            "created_at": s.created_at.isoformat(),
            # Re-normalized on every read (not just at extraction time) —
            # covers any row saved before ProjectSpecService._normalize_digest
            # existed, or saved from a genuinely truncated model response.
            # Without this, an old/partial record would crash the frontend
            # the same way a fresh truncated extraction did (see that
            # method's docstring) the moment the user reopened it.
            "data": spec_service._normalize_digest(dict(s.extracted_data or {})),
            "has_pdf": s.pdf_bytes is not None,
        }
        for s in specs
    ]


@router.delete("/{spec_id}")
async def delete_project_spec(
    spec_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    spec = (
        db.query(ProjectSpec)
        .filter(ProjectSpec.id == spec_id, ProjectSpec.user_id == current_user.id)
        .first()
    )
    if not spec:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="المستند غير موجود.")
    db.delete(spec)
    db.commit()
    return {"status": "success"}


@router.get("/{spec_id}/pdf", response_class=Response)
async def get_project_spec_pdf(
    spec_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    spec = (
        db.query(ProjectSpec)
        .filter(ProjectSpec.id == spec_id, ProjectSpec.user_id == current_user.id)
        .first()
    )
    if not spec or not spec.pdf_bytes:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="مفيش PDF محفوظ للمستند ده.")

    return Response(
        content=spec.pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f"inline; filename={spec.filename or 'spec.pdf'}"},
    )
