import base64
import json
import os

import anthropic

from app.services.json_utils import clean_and_parse_json
from app.services.pricing import estimate_cost_usd

# Powers the standalone "Projects" page (app/routers/projects.py) — NOT
# the drawing Analyze/Archive flow. Where claude_service.py reads one
# rendered drawing PAGE and counts physical components on it, this reads
# an entire project TECHNICAL SPECIFICATION document (a PTS appendix —
# tens of pages of scope-of-work clauses, standards references, design
# criteria and requirement tables, no drawing symbols at all) and distills
# it into a structured digest, so an estimation engineer can see the
# project's real requirements at a glance before ever opening a drawing —
# exactly the "first step" workflow the feature was requested for.
SYSTEM_INSTRUCTION = (
    "You are a senior fire-protection/physical-security estimation"
    " engineer's assistant. You are given a full project technical"
    " specification document (a PTS appendix or equivalent contract"
    " technical document, often tens of pages) for a substation or"
    " industrial facility. Your job is to distill it into a structured"
    " technical digest that lets an estimation engineer fully understand"
    " what the project requires WITHOUT reading the whole document"
    " themselves, before they start take-off / BOQ work from the actual"
    " drawings. Read the ENTIRE document, every page and every table — do"
    " not skip or skim any section. Be exhaustive and precise: this"
    " digest is a working engineering reference, not a marketing"
    " summary, so prefer completeness over brevity, and never silently"
    " drop a requirement, standard reference, or numeric value"
    " (percentages, distances, pressures, durations, counts, sizes)."
    " The one exception is any very long, repetitive point-by-point alarm/"
    " tag list (e.g. a 70+ row SAS/ECC alarm mapping table) — for those,"
    " summarize by total count and a few representative/notable entries"
    " instead of reproducing every row, so the digest stays readable; do"
    " not apply that same shortcut to anything else in the document."
)

EXTRACTION_PROMPT = (
    "Read this entire project technical specification document and"
    " produce a structured technical digest as a single JSON object."
    " Cover every section that exists in the document; leave an"
    ' array/field empty ([] or "") if that section genuinely does not'
    " apply — never invent content that is not in the document. Exact"
    " JSON shape:\n"
    "{\n"
    '  "document_title": string,\n'
    '  "systems_covered": [string],\n'
    '  "precedence_and_general_rules": [string],\n'
    '  "applicable_standards": [{"code": string, "title": string}],\n'
    '  "scope_of_work": [\n'
    "    {\n"
    '      "system": string,\n'
    '      "summary": string,\n'
    '      "key_requirements": [string],\n'
    '      "coverage_areas": [string]\n'
    "    }\n"
    "  ],\n"
    '  "design_criteria": [{"parameter": string, "value": string,'
    ' "reference_standard": string}],\n'
    '  "equipment_specifications": [{"item": string, "requirement":'
    " string}],\n"
    '  "zone_requirement_tables": [\n'
    "    {\n"
    '      "table_name": string,\n'
    '      "rows": [{"zone_or_area": string, "requirement": string}]\n'
    "    }\n"
    "  ],\n"
    '  "alarm_interlock_summary": [{"system": string,'
    ' "total_alarm_points": integer or null, "notable_alarms":'
    " [string]}],\n"
    '  "commissioning_tests": [string],\n'
    '  "submittals_and_annexures": [string],\n'
    '  "open_items_for_estimator": [string]\n'
    "}\n"
    '"open_items_for_estimator" is for anything an estimator needs to'
    " chase separately before pricing: ambiguities, cross-references to"
    " other appendices/documents not included here, blank/unfilled"
    ' project-specific fields (e.g. "as per SOW/PTS" with no value given),'
    " or anything that looked incomplete.\n"
    "Return ONLY the raw JSON object — no markdown fences, no commentary"
    " before or after it."
)


# --------------------------------------------------------------------
# Trial step 2: given the digest extract() above already produced, plus
# an actual drawing (a floor plan / layout PDF), identify every room or
# area shown on the drawing and say exactly what the digest requires for
# each one. This is the deliberately-scoped first trial of a bigger
# planned pipeline — see match_rooms()'s own docstring — so it is kept as
# its own small, separate prompt/schema rather than folded into
# extract() or reusing process.py's component-counting prompts, which
# solve a different problem (counting devices already drawn, not
# deriving what SHOULD be there from a spec).
ROOM_MATCH_SYSTEM_INSTRUCTION = (
    "You are a senior fire-protection/physical-security estimation"
    " engineer. You are given two things: (1) a structured technical"
    " requirement digest already extracted from this project's technical"
    " specification (PTS) document, as JSON, and (2) an actual"
    " engineering drawing (an architectural/layout plan) for the same"
    " project. Your job is to read the drawing and identify every"
    " distinct room, area or zone that is labeled or clearly"
    " identifiable on it, then — using ONLY the requirements already"
    " present in the digest JSON you were given, not general knowledge —"
    " state exactly what is required for each one. Match a drawing room"
    " to a digest category by room type/function (e.g. a room labeled"
    " \"Control Room\" or \"غرفة التحكم\" matches a \"Control Room\" row"
    " in the digest's zone_requirement_tables/scope_of_work/design_criteria,"
    " even if the exact wording differs). If a room on the drawing has no"
    " reasonable match anywhere in the digest, say so explicitly instead"
    " of inventing a requirement — this is an early trial step and"
    " precision matters more than covering every room."
)

ROOM_MATCH_PROMPT_TEMPLATE = (
    "Here is the technical requirement digest already extracted from"
    " this project's PTS document:\n\n{digest_json}\n\n---\n\nNow read"
    " the attached drawing (every page) and identify every distinct"
    " room/area/zone shown on it. For each one, produce a single JSON"
    " object with this exact shape:\n"
    "{{\n"
    '  "rooms": [\n'
    "    {{\n"
    '      "room_name": string,           // as labeled on the drawing\n'
    '      "room_type_matched": string,   // the digest category it was matched to, or "" if none\n'
    '      "page_reference": string,      // page number / grid ref if visible, else ""\n'
    '      "required_systems": [string],  // systems/equipment required per the digest for this room\n'
    '      "requirement_notes": [string]  // supporting detail/caveats pulled from the digest for this room\n'
    "    }}\n"
    "  ],\n"
    '  "unmatched_or_unclear_rooms": [string],           // rooms seen on the drawing with no clear digest match\n'
    '  "digest_categories_not_seen_in_drawing": [string], // digest room/zone categories that never appeared on this drawing\n'
    '  "notes": [string]\n'
    "}}\n"
    "Return ONLY the raw JSON object — no markdown fences, no commentary"
    " before or after it."
)


class ProjectSpecService:

  def __init__(self):
    self.client = anthropic.Anthropic(
        api_key=os.environ.get("ANTHROPIC_API_KEY"),
        max_retries=5,
    )
    # Same env var / default as claude_service.py and
    # claude_chat_service.py — see claude_service.py's comment for why
    # claude-fable-5 is the proven default for this project's real
    # documents/drawings.
    self.model = os.environ.get("CLAUDE_MODEL", "claude-fable-5")

  # 16000 (extract) / 8192 (match_rooms) are the exact values already
  # proven to work as plain, non-streaming calls — 8192 was the original
  # working baseline before this file existed at all (see
  # claude_service.py/claude_chat_service.py's own history), and 16000
  # was the value that fixed the very first truncation report on this
  # feature. Neither is anywhere near the ~10-minute-estimated-output
  # size where the Anthropic SDK refuses a non-streaming call outright
  # ("Streaming is required for operations that may take longer than 10
  # minutes") — that guard is exactly what broke extract() the moment a
  # single call was pushed to 64000 max_tokens instead. Per the user's
  # own suggestion, the fix is NOT one giant call — it's calling the
  # model repeatedly at the proven-safe size and stitching the replies
  # together (see _create_message_with_continuation below), so the total
  # output has no real ceiling without ever tripping that guard.
  EXTRACT_ROUND_MAX_TOKENS = 16000
  EXTRACT_MAX_ROUNDS = 8  # up to 128,000 output tokens total
  MATCH_ROOMS_ROUND_MAX_TOKENS = 8192
  MATCH_ROOMS_MAX_ROUNDS = 8  # up to 65,536 output tokens total

  def _create_message_with_continuation(
      self, *, system: str, messages: list, max_tokens_per_round: int, max_rounds: int
  ) -> dict:
    """Calls messages.create() up to `max_rounds` times at a small, safe
    `max_tokens_per_round` instead of one huge call, using Claude's
    standard continuation technique: when a round is cut off
    (stop_reason == "max_tokens"), the next round replays the exact same
    messages PLUS one new "assistant" turn whose content is everything
    accumulated so far. Ending a request with an assistant turn is Claude's
    documented "prefill" mechanism — the model treats it as its own
    in-progress reply and generates the NEXT tokens to continue it,
    rather than restarting or repeating itself. Concatenating each
    round's new text therefore reconstructs exactly the same raw text a
    single, unbounded call would have produced — this only works because
    the prompt asks for nothing but raw JSON with no commentary, so there
    is no per-round preamble/wrapper to strip before concatenating.

    Returns {"text", "response" (the LAST round's Message, for
    .model/.stop_reason), "truncated" (still cut off after max_rounds),
    "input_tokens", "output_tokens"} — the token counts are SUMMED across
    every round, since each round is its own separately-billed API call;
    reading them off only the last round's `.usage` (as a single-call
    design would) would silently under-report cost/usage for any
    document that needed more than one round."""
    base_messages = list(messages)
    full_text = ""
    last_response = None
    total_input_tokens = 0
    total_output_tokens = 0

    for round_num in range(max_rounds):
      call_messages = (
          base_messages if round_num == 0
          else base_messages + [{"role": "assistant", "content": full_text}]
      )
      response = self.client.messages.create(
          model=self.model, max_tokens=max_tokens_per_round, system=system, messages=call_messages,
      )
      last_response = response
      total_input_tokens += response.usage.input_tokens
      total_output_tokens += response.usage.output_tokens
      full_text += next((b.text for b in response.content if hasattr(b, "text")), "")

      if response.stop_reason != "max_tokens":
        return {
            "text": full_text, "response": last_response, "truncated": False,
            "input_tokens": total_input_tokens, "output_tokens": total_output_tokens,
        }

    return {
        "text": full_text, "response": last_response, "truncated": True,
        "input_tokens": total_input_tokens, "output_tokens": total_output_tokens,
    }

  def extract(self, pdf_bytes: bytes) -> dict:
    """Synchronous, blocking Anthropic call — the router offloads this to
    a ThreadPoolExecutor (see app/routers/projects.py) so a single large
    document — and now potentially several chained calls, see
    _create_message_with_continuation — can easily take 30-90+ seconds,
    more for a document needing more than one round) doesn't freeze the
    whole single-process uvicorn server for every other user, the same
    concurrency bug already fixed for process.py's ERPNext/PDF-render
    calls this session. Returns the parsed digest dict, or a dict with
    just `open_items_for_estimator` + `api_usage` populated if parsing
    genuinely fails (mirrors claude_service.py's own error-fallback
    shape, so the frontend always gets SOME JSON back, never a raw
    exception)."""
    file_base64 = base64.b64encode(pdf_bytes).decode("utf-8")

    try:
      result = self._create_message_with_continuation(
          system=SYSTEM_INSTRUCTION,
          messages=[{
              "role": "user",
              "content": [
                  {
                      "type": "document",
                      "source": {
                          "type": "base64",
                          "media_type": "application/pdf",
                          "data": file_base64,
                      },
                  },
                  {"type": "text", "text": EXTRACTION_PROMPT},
              ],
          }],
          max_tokens_per_round=self.EXTRACT_ROUND_MAX_TOKENS,
          max_rounds=self.EXTRACT_MAX_ROUNDS,
      )
      response = result["response"]

      result_text = result["text"].strip()
      parsed = clean_and_parse_json(result_text) if result_text else {}
      # See _normalize_digest()'s docstring — this is what stops a
      # truncated/partial model response (missing or wrong-typed fields)
      # from crashing the frontend, which assumes every field below is
      # always present with the right type.
      parsed = self._normalize_digest(parsed)

      # A plain boolean, not a hardcoded-language message: the frontend
      # already knows which UI language the user picked (see lib/i18n.ts)
      # and renders its own localized warning from this flag — a message
      # baked into the JSON here would show in the wrong language for an
      # English-mode user, which is exactly what happened before this
      # fix (an Arabic-only string appended server-side regardless of
      # the caller's language). True here means even EXTRACT_MAX_ROUNDS
      # rounds of continuation weren't enough — genuinely rare.
      parsed["truncated"] = result["truncated"]

      parsed["api_usage"] = {
          "provider": "claude",
          "model": response.model,
          "input_tokens": result["input_tokens"],
          "output_tokens": result["output_tokens"],
          "total_cost_usd": estimate_cost_usd(
              response.model,
              result["input_tokens"],
              result["output_tokens"],
          ),
      }
      return parsed

    except Exception as e:
      return {
          "document_title": "",
          "systems_covered": [],
          "precedence_and_general_rules": [],
          "applicable_standards": [],
          "scope_of_work": [],
          "design_criteria": [],
          "equipment_specifications": [],
          "zone_requirement_tables": [],
          "alarm_interlock_summary": [],
          "commissioning_tests": [],
          "submittals_and_annexures": [],
          "open_items_for_estimator": [f"❌ فشل تحليل المستند: {str(e)}"],
          "truncated": False,
          "api_usage": {"provider": "claude", "model": self.model, "input_tokens": 0,
                         "output_tokens": 0, "total_cost_usd": 0.0},
      }

  def _normalize_digest(self, parsed: dict) -> dict:
    """Guarantees every field EXTRACTION_PROMPT's schema promises is
    present with the right type, no matter what the model actually
    returned. This matters even OUTSIDE the max_tokens-truncation case:
    a real 39-page document was observed to cut the raw response off
    mid-string inside "scope_of_work", which meant every field the
    schema defines AFTER that point (design_criteria,
    zone_requirement_tables, alarm_interlock_summary, ...) was simply
    absent from the parsed dict — not an empty list, not null, just
    missing. The frontend's ProjectDigestView calls `.length`/`.map`/
    `.join()` directly on these fields (they're typed as always-present
    arrays — see api.ts's ProjectSpecData), so a genuinely missing key
    threw a client-side exception that took down the whole /projects
    page instead of just leaving that one section looking empty. Same
    risk if the model ever emits `null` for a field, or a string where
    an array was expected, etc. — clean_and_parse_json()/json_repair can
    produce a structurally-valid-but-wrong-shaped dict, not just a
    perfectly-shaped one."""
    if not isinstance(parsed, dict):
      parsed = {}

    def as_str(v) -> str:
      return v if isinstance(v, str) else ("" if v is None else str(v))

    def as_list(v) -> list:
      return v if isinstance(v, list) else []

    def as_str_list(v) -> list:
      return [as_str(x) for x in as_list(v)]

    def as_dict(v) -> dict:
      return v if isinstance(v, dict) else {}

    parsed["document_title"] = as_str(parsed.get("document_title"))
    parsed["systems_covered"] = as_str_list(parsed.get("systems_covered"))
    parsed["precedence_and_general_rules"] = as_str_list(parsed.get("precedence_and_general_rules"))

    parsed["applicable_standards"] = [
        {"code": as_str(d.get("code")), "title": as_str(d.get("title"))}
        for d in (as_dict(x) for x in as_list(parsed.get("applicable_standards")))
    ]

    parsed["scope_of_work"] = [
        {
            "system": as_str(d.get("system")),
            "summary": as_str(d.get("summary")),
            "key_requirements": as_str_list(d.get("key_requirements")),
            "coverage_areas": as_str_list(d.get("coverage_areas")),
        }
        for d in (as_dict(x) for x in as_list(parsed.get("scope_of_work")))
    ]

    parsed["design_criteria"] = [
        {
            "parameter": as_str(d.get("parameter")),
            "value": as_str(d.get("value")),
            "reference_standard": as_str(d.get("reference_standard")),
        }
        for d in (as_dict(x) for x in as_list(parsed.get("design_criteria")))
    ]

    parsed["equipment_specifications"] = [
        {"item": as_str(d.get("item")), "requirement": as_str(d.get("requirement"))}
        for d in (as_dict(x) for x in as_list(parsed.get("equipment_specifications")))
    ]

    zone_tables = []
    for d in (as_dict(x) for x in as_list(parsed.get("zone_requirement_tables"))):
      rows = [
          {"zone_or_area": as_str(r.get("zone_or_area")), "requirement": as_str(r.get("requirement"))}
          for r in (as_dict(x) for x in as_list(d.get("rows")))
      ]
      zone_tables.append({"table_name": as_str(d.get("table_name")), "rows": rows})
    parsed["zone_requirement_tables"] = zone_tables

    alarms = []
    for d in (as_dict(x) for x in as_list(parsed.get("alarm_interlock_summary"))):
      total = d.get("total_alarm_points")
      alarms.append({
          "system": as_str(d.get("system")),
          "total_alarm_points": total if isinstance(total, int) else None,
          "notable_alarms": as_str_list(d.get("notable_alarms")),
      })
    parsed["alarm_interlock_summary"] = alarms

    parsed["commissioning_tests"] = as_str_list(parsed.get("commissioning_tests"))
    parsed["submittals_and_annexures"] = as_str_list(parsed.get("submittals_and_annexures"))
    parsed["open_items_for_estimator"] = as_str_list(parsed.get("open_items_for_estimator"))
    parsed["truncated"] = bool(parsed.get("truncated", False))

    return parsed

  def _normalize_room_match(self, parsed: dict) -> dict:
    """Same purpose as _normalize_digest() (see its docstring) applied to
    match_rooms()'s smaller schema — guarantees `rooms` and the three
    string-list fields are always present with the right shape, so a
    truncated/malformed response can't crash RoomMatchTrial on the
    frontend either."""
    if not isinstance(parsed, dict):
      parsed = {}

    def as_str(v) -> str:
      return v if isinstance(v, str) else ("" if v is None else str(v))

    def as_list(v) -> list:
      return v if isinstance(v, list) else []

    def as_str_list(v) -> list:
      return [as_str(x) for x in as_list(v)]

    def as_dict(v) -> dict:
      return v if isinstance(v, dict) else {}

    parsed["rooms"] = [
        {
            "room_name": as_str(d.get("room_name")),
            "room_type_matched": as_str(d.get("room_type_matched")),
            "page_reference": as_str(d.get("page_reference")),
            "required_systems": as_str_list(d.get("required_systems")),
            "requirement_notes": as_str_list(d.get("requirement_notes")),
        }
        for d in (as_dict(x) for x in as_list(parsed.get("rooms")))
    ]
    parsed["unmatched_or_unclear_rooms"] = as_str_list(parsed.get("unmatched_or_unclear_rooms"))
    parsed["digest_categories_not_seen_in_drawing"] = as_str_list(parsed.get("digest_categories_not_seen_in_drawing"))
    parsed["notes"] = as_str_list(parsed.get("notes"))
    parsed["truncated"] = bool(parsed.get("truncated", False))

    return parsed

  def match_rooms(self, digest: dict, drawing_pdf_bytes: bytes) -> dict:
    """Trial step 2 of the planned multi-step pipeline (per the user's own
    framing: "let us try to train the model for this initial step as a
    trial, then we will train it on all the steps") — takes the digest
    extract() already produced for this project and a real drawing, and
    asks the model to read the drawing's actual rooms/areas and state
    what the digest requires for each one. Deliberately separate from
    extract() (different inputs: JSON + a drawing, not just a spec
    document) and from process.py's component-counting flow (this
    derives what SHOULD exist per the spec, not what's already drawn).

    Same blocking-call-must-be-offloaded requirement as extract() — see
    that method's docstring and app/routers/projects.py's executor.
    """
    file_base64 = base64.b64encode(drawing_pdf_bytes).decode("utf-8")
    # compact (no extra whitespace) to keep this from padding the input
    # token count for no benefit — the model doesn't need pretty-printing.
    digest_json = json.dumps(digest, ensure_ascii=False, separators=(",", ":"))
    prompt = ROOM_MATCH_PROMPT_TEMPLATE.format(digest_json=digest_json)

    try:
      result = self._create_message_with_continuation(
          system=ROOM_MATCH_SYSTEM_INSTRUCTION,
          messages=[{
              "role": "user",
              "content": [
                  {
                      "type": "document",
                      "source": {
                          "type": "base64",
                          "media_type": "application/pdf",
                          "data": file_base64,
                      },
                  },
                  {"type": "text", "text": prompt},
              ],
          }],
          max_tokens_per_round=self.MATCH_ROOMS_ROUND_MAX_TOKENS,
          max_rounds=self.MATCH_ROOMS_MAX_ROUNDS,
      )
      response = result["response"]

      result_text = result["text"].strip()
      parsed = clean_and_parse_json(result_text) if result_text else {}
      parsed = self._normalize_room_match(parsed)
      # See extract()'s identical comment — a plain boolean, not a
      # hardcoded-language message, so the frontend can show its own
      # localized warning in whichever UI language is active.
      parsed["truncated"] = result["truncated"]

      parsed["api_usage"] = {
          "provider": "claude",
          "model": response.model,
          "input_tokens": result["input_tokens"],
          "output_tokens": result["output_tokens"],
          "total_cost_usd": estimate_cost_usd(
              response.model,
              result["input_tokens"],
              result["output_tokens"],
          ),
      }
      return parsed

    except Exception as e:
      return {
          "rooms": [],
          "unmatched_or_unclear_rooms": [],
          "digest_categories_not_seen_in_drawing": [],
          "notes": [f"❌ فشل تحليل المخطط: {str(e)}"],
          "truncated": False,
          "api_usage": {"provider": "claude", "model": self.model, "input_tokens": 0,
                         "output_tokens": 0, "total_cost_usd": 0.0},
      }
