"use client";

import { useEffect, useRef, useState } from "react";
import { UploadCloud, Loader2, Save, Eye, EyeOff, Trash2, FolderOpen, FileText } from "lucide-react";
import { useAuthStore } from "@/lib/auth-store";
import { useT } from "@/lib/i18n";
import {
  ApiError,
  deleteProjectSpec,
  extractProjectSpec,
  getMyProjectSpecs,
  projectSpecPdfUrl,
  saveProjectSpec,
  type ProjectSpecData,
  type ProjectSpecSummary,
} from "@/lib/api";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ProjectDigestView } from "@/components/project-digest-view";
import { RoomMatchTrial } from "@/components/room-match-trial";

function formatDate(iso: string) {
  try {
    return new Date(iso).toLocaleString();
  } catch {
    return iso;
  }
}

/** Standalone "Projects" tool — deliberately NOT wired into the drawing
 * Analyze/Archive flow (see app/routers/projects.py). Upload a project
 * technical specification (a PTS appendix) and get a structured digest of
 * what the project actually requires, before ever opening a drawing —
 * the estimation engineer's real first step. A second trial capability
 * (RoomMatchTrial below) lets the engineer additionally upload a real
 * drawing and see what the digest requires room-by-room — an initial
 * trial of a larger planned multi-step pipeline, per the user's own
 * framing. */
export default function ProjectsPage() {
  const token = useAuthStore((s) => s.token);
  const t = useT();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [file, setFile] = useState<File | null>(null);
  const [extracting, setExtracting] = useState(false);
  const [digest, setDigest] = useState<ProjectSpecData | null>(null);
  const [digestFilename, setDigestFilename] = useState("");
  const [error, setError] = useState<string | null>(null);

  const [saving, setSaving] = useState(false);
  const [savedId, setSavedId] = useState<number | null>(null);

  const [specs, setSpecs] = useState<ProjectSpecSummary[] | null>(null);
  const [specsError, setSpecsError] = useState<string | null>(null);
  const [viewedSpecId, setViewedSpecId] = useState<number | null>(null);

  function loadSpecs() {
    if (!token) return;
    getMyProjectSpecs(token)
      .then(setSpecs)
      .catch((err) => setSpecsError(err instanceof ApiError ? err.message : String(err)));
  }

  useEffect(() => {
    loadSpecs();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  async function handleExtract() {
    if (!file || !token) return;
    setExtracting(true);
    setError(null);
    setDigest(null);
    setSavedId(null);
    try {
      const res = await extractProjectSpec(token, file);
      setDigest(res.data);
      setDigestFilename(res.filename);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : String(err));
    } finally {
      setExtracting(false);
    }
  }

  async function handleSave() {
    if (!digest || !token) return;
    setSaving(true);
    setError(null);
    try {
      const res = await saveProjectSpec(token, digestFilename || "project-spec.pdf", digest, file ?? undefined);
      setSavedId(res.id);
      loadSpecs();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : String(err));
    } finally {
      setSaving(false);
    }
  }

  function handleViewSpec(spec: ProjectSpecSummary) {
    if (viewedSpecId === spec.id) {
      setViewedSpecId(null);
      return;
    }
    setViewedSpecId(spec.id);
    // Loading a saved spec also makes it the "active" digest so the room-
    // matching trial below can run against it without re-extracting.
    setDigest(spec.data);
    setDigestFilename(spec.filename);
    setSavedId(spec.id);
    setFile(null);
    setError(null);
  }

  async function handleDeleteSpec(specId: number) {
    if (!token) return;
    try {
      await deleteProjectSpec(token, specId);
      setSpecs((prev) => prev?.filter((s) => s.id !== specId) ?? prev);
      if (viewedSpecId === specId) setViewedSpecId(null);
      if (savedId === specId) setSavedId(null);
    } catch (err) {
      setSpecsError(err instanceof ApiError ? err.message : String(err));
    }
  }

  return (
    <div className="p-6 space-y-5">
      <div>
        <h1 className="text-lg font-semibold text-text-primary">{t.projects_title}</h1>
        <p className="text-sm text-text-secondary mt-0.5">{t.projects_subtitle}</p>
      </div>

      <Card>
        <CardContent className="pt-5 space-y-4">
          <div className="space-y-1.5">
            <Label>{t.projects_upload_label}</Label>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="w-full h-9 flex items-center gap-2 px-3 rounded-[var(--radius-sm)] border border-dashed border-border bg-bg-elevated-2 text-sm text-text-secondary hover:border-accent hover:text-text-primary transition-colors md:max-w-md"
            >
              <UploadCloud className="h-4 w-4" />
              <span className="truncate">{file ? file.name : t.projects_upload_label}</span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="application/pdf"
              className="hidden"
              onChange={(e) => {
                setFile(e.target.files?.[0] ?? null);
                setDigest(null);
                setSavedId(null);
                setError(null);
              }}
            />
            <p className="text-xs text-text-muted">{t.projects_upload_hint}</p>
          </div>

          <Button onClick={handleExtract} disabled={!file || extracting}>
            {extracting ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" /> {t.projects_extracting}
              </>
            ) : (
              t.projects_extract_btn
            )}
          </Button>
        </CardContent>
      </Card>

      {error && (
        <div className="text-sm text-danger bg-danger/10 border border-danger/30 rounded-[var(--radius-md)] px-4 py-3">
          {error}
        </div>
      )}

      {digest && (
        <>
          <div className="flex items-center gap-3 flex-wrap">
            <h2 className="text-base font-semibold text-text-primary">{t.projects_digest_title}</h2>
            <div className="flex-1 min-w-[180px] max-w-xs">
              <Input
                value={digestFilename}
                onChange={(e) => setDigestFilename(e.target.value)}
                placeholder={t.projects_save_filename_label}
                className="h-8 text-sm"
              />
            </div>
            <Button variant="secondary" onClick={handleSave} disabled={saving || savedId !== null}>
              <Save className="h-4 w-4" />
              {savedId !== null ? t.projects_saved_ok : saving ? t.projects_extracting : t.projects_save_btn}
            </Button>
          </div>

          {digest.truncated && (
            <div className="text-sm text-warning bg-warning/10 border border-warning/30 rounded-[var(--radius-md)] px-4 py-3">
              {t.projects_extract_truncated_warning}
            </div>
          )}

          <ProjectDigestView data={digest} />

          {token && <RoomMatchTrial token={token} digest={digest} />}
        </>
      )}

      <Card>
        <CardContent className="pt-5">
          <h2 className="text-base font-semibold text-text-primary mb-3">{t.projects_saved_list_title}</h2>

          {specsError && <div className="text-sm text-danger mb-2">{specsError}</div>}

          {specs === null && !specsError && (
            <div className="flex items-center gap-2 text-sm text-text-secondary">
              <Loader2 className="h-4 w-4 animate-spin" /> {t.projects_saved_loading}
            </div>
          )}

          {specs !== null && specs.length === 0 && (
            <div className="flex flex-col items-center text-center gap-2 py-8">
              <FolderOpen className="h-8 w-8 text-text-muted" />
              <p className="text-sm text-text-secondary">{t.projects_saved_empty}</p>
            </div>
          )}

          <div className="space-y-2">
            {specs?.map((spec) => (
              <div
                key={spec.id}
                className="flex items-center gap-3 flex-wrap rounded-[var(--radius-sm)] border border-border-subtle bg-bg-elevated-2 px-3 py-2.5"
              >
                <FileText className="h-4 w-4 text-text-muted shrink-0" />
                <div className="flex-1 min-w-[160px]">
                  <div className="text-sm font-medium text-text-primary truncate">{spec.filename}</div>
                  <div className="text-xs text-text-secondary">{formatDate(spec.created_at)}</div>
                </div>
                <div className="flex items-center gap-1.5">
                  {spec.has_pdf && (
                    <a href={projectSpecPdfUrl(spec.id)} target="_blank" rel="noreferrer">
                      <Button size="sm" variant="ghost">
                        {t.projects_view_pdf_btn}
                      </Button>
                    </a>
                  )}
                  <Button size="sm" variant="secondary" onClick={() => handleViewSpec(spec)}>
                    {viewedSpecId === spec.id ? (
                      <>
                        <EyeOff className="h-3.5 w-3.5" /> {t.projects_hide_btn}
                      </>
                    ) : (
                      <>
                        <Eye className="h-3.5 w-3.5" /> {t.projects_view_btn}
                      </>
                    )}
                  </Button>
                  <DeleteButton onConfirm={() => handleDeleteSpec(spec.id)} label={t.projects_delete_btn} confirmLabel={t.projects_delete_confirm} confirmOkLabel={t.projects_delete_ok} />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function DeleteButton({
  onConfirm,
  label,
  confirmLabel,
  confirmOkLabel,
}: {
  onConfirm: () => void;
  label: string;
  confirmLabel: string;
  confirmOkLabel: string;
}) {
  const [confirming, setConfirming] = useState(false);
  if (confirming) {
    return (
      <div className="flex items-center gap-1.5">
        <span className="text-xs text-danger">{confirmLabel}</span>
        <Button size="sm" variant="destructive" onClick={onConfirm}>
          {confirmOkLabel}
        </Button>
      </div>
    );
  }
  return (
    <Button size="sm" variant="ghost" onClick={() => setConfirming(true)}>
      <Trash2 className="h-3.5 w-3.5" /> {label}
    </Button>
  );
}
