"use client";

import type { ReactNode } from "react";
import { useT } from "@/lib/i18n";
import type { ProjectSpecData } from "@/lib/api";
import { Card, CardContent } from "@/components/ui/card";

/** Read-only, organized display of a ProjectSpecData digest — one section
 * per field in the schema ProjectSpecService.extract() returns (see
 * api.ts). Deliberately plain HTML tables/lists rather than react-table:
 * this is a reference document to read top-to-bottom, not a dataset that
 * needs sorting/filtering/CSV export the way the BOQ component table
 * does. */
export function ProjectDigestView({ data }: { data: ProjectSpecData }) {
  const t = useT();

  return (
    <div className="space-y-4">
      {data.document_title && (
        <div>
          <div className="text-xs text-text-muted">{t.projects_section_title_ar}</div>
          <h2 className="text-base font-semibold text-text-primary">{data.document_title}</h2>
        </div>
      )}

      <Section title={t.projects_section_systems} empty={data.systems_covered.length === 0}>
        <TagList items={data.systems_covered} />
      </Section>

      <Section
        title={t.projects_section_general_rules}
        empty={data.precedence_and_general_rules.length === 0}
      >
        <BulletList items={data.precedence_and_general_rules} />
      </Section>

      <Section title={t.projects_section_standards} empty={data.applicable_standards.length === 0}>
        <SimpleTable
          headers={[t.projects_col_standard_code, t.projects_col_standard_title]}
          rows={data.applicable_standards.map((s) => [s.code, s.title])}
        />
      </Section>

      <Section title={t.projects_section_scope} empty={data.scope_of_work.length === 0}>
        <div className="space-y-3">
          {data.scope_of_work.map((item, i) => (
            <div key={i} className="rounded-[var(--radius-sm)] border border-border-subtle bg-bg-elevated-2 p-3">
              <div className="text-sm font-semibold text-text-primary">{item.system}</div>
              {item.summary && <p className="text-sm text-text-secondary mt-1">{item.summary}</p>}
              {item.key_requirements.length > 0 && (
                <div className="mt-2">
                  <div className="text-xs text-text-muted mb-1">{t.projects_scope_key_requirements}</div>
                  <BulletList items={item.key_requirements} />
                </div>
              )}
              {item.coverage_areas.length > 0 && (
                <div className="mt-2">
                  <div className="text-xs text-text-muted mb-1">{t.projects_scope_coverage_areas}</div>
                  <TagList items={item.coverage_areas} />
                </div>
              )}
            </div>
          ))}
        </div>
      </Section>

      <Section title={t.projects_section_design_criteria} empty={data.design_criteria.length === 0}>
        <SimpleTable
          headers={[t.projects_col_parameter, t.projects_col_value, t.projects_col_reference]}
          rows={data.design_criteria.map((d) => [d.parameter, d.value, d.reference_standard])}
        />
      </Section>

      <Section title={t.projects_section_equipment} empty={data.equipment_specifications.length === 0}>
        <SimpleTable
          headers={[t.projects_col_item, t.projects_col_requirement]}
          rows={data.equipment_specifications.map((e) => [e.item, e.requirement])}
        />
      </Section>

      <Section title={t.projects_section_zone_tables} empty={data.zone_requirement_tables.length === 0}>
        <div className="space-y-3">
          {data.zone_requirement_tables.map((zt, i) => (
            <div key={i}>
              <div className="text-sm font-medium text-text-primary mb-1">{zt.table_name}</div>
              <SimpleTable
                headers={[t.projects_col_zone, t.projects_col_requirement]}
                rows={zt.rows.map((r) => [r.zone_or_area, r.requirement])}
              />
            </div>
          ))}
        </div>
      </Section>

      <Section title={t.projects_section_alarms} empty={data.alarm_interlock_summary.length === 0}>
        <SimpleTable
          headers={[t.projects_col_alarm_system, t.projects_col_alarm_points, t.projects_col_notable_alarms]}
          rows={data.alarm_interlock_summary.map((a) => [
            a.system,
            a.total_alarm_points != null ? String(a.total_alarm_points) : "—",
            a.notable_alarms.join("، "),
          ])}
        />
      </Section>

      <Section title={t.projects_section_commissioning} empty={data.commissioning_tests.length === 0}>
        <BulletList items={data.commissioning_tests} />
      </Section>

      <Section title={t.projects_section_submittals} empty={data.submittals_and_annexures.length === 0}>
        <BulletList items={data.submittals_and_annexures} />
      </Section>

      {data.open_items_for_estimator.length > 0 && (
        <Card className="border-s-4 border-s-warning">
          <CardContent className="pt-4">
            <h3 className="text-sm font-semibold text-warning mb-2">{t.projects_section_open_items}</h3>
            <BulletList items={data.open_items_for_estimator} />
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function Section({ title, empty, children }: { title: string; empty: boolean; children: ReactNode }) {
  const t = useT();
  return (
    <Card>
      <CardContent className="pt-4">
        <h3 className="text-sm font-semibold text-text-primary mb-2">{title}</h3>
        {empty ? <p className="text-sm text-text-muted">{t.projects_empty_section}</p> : children}
      </CardContent>
    </Card>
  );
}

function BulletList({ items }: { items: string[] }) {
  return (
    <ul className="space-y-1.5">
      {items.map((item, i) => (
        <li
          key={i}
          className="text-sm text-text-secondary bg-bg-elevated-2 rounded-[var(--radius-sm)] px-3 py-2"
        >
          🔹 {item}
        </li>
      ))}
    </ul>
  );
}

function TagList({ items }: { items: string[] }) {
  return (
    <div className="flex flex-wrap gap-1.5">
      {items.map((item, i) => (
        <span
          key={i}
          className="text-xs text-text-secondary bg-bg-elevated-2 border border-border-subtle rounded-full px-2.5 py-1"
        >
          {item}
        </span>
      ))}
    </div>
  );
}

function SimpleTable({ headers, rows }: { headers: string[]; rows: string[][] }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm border-collapse">
        <thead>
          <tr className="border-b border-border-subtle">
            {headers.map((h, i) => (
              <th key={i} className="text-start font-medium text-text-muted px-2.5 py-1.5 whitespace-nowrap">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, ri) => (
            <tr key={ri} className="border-b border-border-subtle/60 last:border-0">
              {row.map((cell, ci) => (
                <td key={ci} className="text-text-secondary px-2.5 py-1.5 align-top">
                  {cell || "—"}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
