"use client";

import { useRef, useState } from "react";
import { UploadCloud, Loader2, Search } from "lucide-react";
import { useT } from "@/lib/i18n";
import { ApiError, matchProjectRooms, type ProjectSpecData, type RoomMatchResult } from "@/lib/api";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

/** Trial step 2 of the planned multi-step pipeline (per the user's own
 * framing: "let us try to train the model for this initial step as a
 * trial, then we will train it on all the steps"). Given a digest already
 * on screen (just extracted, or loaded from a saved ProjectSpec) plus an
 * uploaded drawing, asks the model what each room/area on the drawing
 * requires per the digest. Nothing here is persisted — see
 * app/routers/projects.py's /match-rooms comment — this is purely a
 * review/trial surface for now. */
export function RoomMatchTrial({ token, digest }: { token: string; digest: ProjectSpecData }) {
  const t = useT();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [file, setFile] = useState<File | null>(null);
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<RoomMatchResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function handleRun() {
    if (!file || !token) return;
    setRunning(true);
    setError(null);
    setResult(null);
    try {
      const res = await matchProjectRooms(token, digest, file);
      setResult(res.data);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : String(err));
    } finally {
      setRunning(false);
    }
  }

  return (
    <Card>
      <CardContent className="pt-5 space-y-4">
        <div>
          <h3 className="text-sm font-semibold text-text-primary">{t.projects_match_rooms_title}</h3>
          <p className="text-xs text-text-secondary mt-1">{t.projects_match_rooms_subtitle}</p>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="h-9 flex items-center gap-2 px-3 rounded-[var(--radius-sm)] border border-dashed border-border bg-bg-elevated-2 text-sm text-text-secondary hover:border-accent hover:text-text-primary transition-colors max-w-xs"
          >
            <UploadCloud className="h-4 w-4 shrink-0" />
            <span className="truncate">{file ? file.name : t.projects_match_rooms_upload_label}</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="application/pdf"
            className="hidden"
            onChange={(e) => {
              setFile(e.target.files?.[0] ?? null);
              setResult(null);
              setError(null);
            }}
          />
          <Button onClick={handleRun} disabled={!file || running}>
            {running ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" /> {t.projects_match_rooms_running}
              </>
            ) : (
              <>
                <Search className="h-4 w-4" /> {t.projects_match_rooms_btn}
              </>
            )}
          </Button>
        </div>

        {error && (
          <div className="text-sm text-danger bg-danger/10 border border-danger/30 rounded-[var(--radius-md)] px-4 py-3">
            {error}
          </div>
        )}

        {result && (
          <div className="space-y-4">
            {result.truncated && (
              <div className="text-sm text-warning bg-warning/10 border border-warning/30 rounded-[var(--radius-md)] px-4 py-3">
                {t.projects_match_rooms_truncated_warning}
              </div>
            )}

            {result.rooms.length > 0 && (
              <div>
                <h4 className="text-xs font-semibold text-text-muted mb-2">
                  {t.projects_match_rooms_results_title}
                </h4>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm border-collapse">
                    <thead>
                      <tr className="border-b border-border-subtle">
                        <th className="text-start font-medium text-text-muted px-2.5 py-1.5">
                          {t.projects_col_room_name}
                        </th>
                        <th className="text-start font-medium text-text-muted px-2.5 py-1.5">
                          {t.projects_col_room_matched}
                        </th>
                        <th className="text-start font-medium text-text-muted px-2.5 py-1.5">
                          {t.projects_col_room_page}
                        </th>
                        <th className="text-start font-medium text-text-muted px-2.5 py-1.5">
                          {t.projects_col_room_required}
                        </th>
                        <th className="text-start font-medium text-text-muted px-2.5 py-1.5">
                          {t.projects_col_room_notes}
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {result.rooms.map((room, i) => (
                        <tr key={i} className="border-b border-border-subtle/60 last:border-0 align-top">
                          <td className="px-2.5 py-1.5 text-text-primary font-medium whitespace-nowrap">
                            {room.room_name}
                          </td>
                          <td className="px-2.5 py-1.5 text-text-secondary whitespace-nowrap">
                            {room.room_type_matched || "—"}
                          </td>
                          <td className="px-2.5 py-1.5 text-text-secondary whitespace-nowrap">
                            {room.page_reference || "—"}
                          </td>
                          <td className="px-2.5 py-1.5 text-text-secondary">
                            {room.required_systems.length > 0 ? room.required_systems.join("، ") : "—"}
                          </td>
                          <td className="px-2.5 py-1.5 text-text-secondary">
                            {room.requirement_notes.length > 0 ? room.requirement_notes.join(" • ") : "—"}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {result.unmatched_or_unclear_rooms.length > 0 && (
              <NoteList title={t.projects_match_rooms_unmatched} items={result.unmatched_or_unclear_rooms} />
            )}
            {result.digest_categories_not_seen_in_drawing.length > 0 && (
              <NoteList
                title={t.projects_match_rooms_unseen}
                items={result.digest_categories_not_seen_in_drawing}
              />
            )}
            {result.notes.length > 0 && <NoteList title={t.projects_match_rooms_notes} items={result.notes} />}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function NoteList({ title, items }: { title: string; items: string[] }) {
  return (
    <div>
      <h4 className="text-xs font-semibold text-text-muted mb-1.5">{title}</h4>
      <ul className="space-y-1">
        {items.map((item, i) => (
          <li key={i} className="text-sm text-text-secondary bg-bg-elevated-2 rounded-[var(--radius-sm)] px-3 py-2">
            🔹 {item}
          </li>
        ))}
      </ul>
    </div>
  );
}
