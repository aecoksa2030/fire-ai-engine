"use client";

import { create } from "zustand";

/**
 * Translation keys are added incrementally as each screen is built (same
 * approach the Streamlit version used with its TRANSLATIONS dict) — this
 * file grows alongside src/app/**. Keeping one flat dict per language
 * (not nested namespaces) matches that original structure so porting
 * strings across is a straight copy.
 */
export const translations = {
  ar: {
    brand_name: "AECO",
    brand_tagline: "محرك الحريق والأمن بالذكاء الاصطناعي",
    login_title: "تسجيل الدخول",
    login_subtitle: "من فضلك سجّل الدخول للمتابعة",
    username: "اسم المستخدم",
    password: "كلمة المرور",
    login_btn: "دخول",
    login_failed: "فشل تسجيل الدخول",
    logging_in: "جاري الدخول...",
    nav_projects: "📋 المشاريع",
    nav_analyze: "🚀 تحليل مخطط جديد",
    nav_archive: "📁 الجلسات المحفوظة والأرشيف",
    nav_users: "👥 إدارة المستخدمين",
    logout: "🚪 تسجيل الخروج",
    theme_dark: "🌙 غامق",
    theme_light: "☀️ فاتح",
    language_label: "اللغة",

    archive_title: "📁 الجلسات المحفوظة والأرشيف",
    archive_subtitle: "استعرض التحليلات المحفوظة سابقًا، أعد تسميتها أو احذفها.",
    archive_loading: "جاري التحميل...",
    archive_empty: "لا توجد جلسات محفوظة بعد.",
    archive_view_btn: "عرض",
    archive_hide_btn: "إخفاء",
    archive_rename_btn: "إعادة تسمية",
    archive_rename_save: "حفظ",
    archive_cancel: "إلغاء",
    archive_delete_btn: "حذف",
    archive_delete_confirm: "متأكد من الحذف؟",
    archive_delete_ok: "تأكيد الحذف",
    archive_no_data: "لا توجد بيانات تحليل محفوظة لهذه الجلسة.",

    users_title: "👥 إدارة المستخدمين",
    users_subtitle: "أضف مستخدمين جدد، غيّر الصلاحيات، أو أعد ضبط كلمات المرور.",
    users_create_title: "إضافة مستخدم جديد",
    users_create_btn: "إنشاء مستخدم",
    users_create_ok: "تم إنشاء المستخدم بنجاح",
    users_list_title: "المستخدمون الحاليون",
    users_list_empty: "لا يوجد مستخدمون.",
    users_col_username: "اسم المستخدم",
    users_col_email: "البريد الإلكتروني",
    users_col_role: "الصلاحية",
    users_new_role_label: "الصلاحية الجديدة",
    users_change_role_btn: "تحديث الصلاحية",
    users_role_updated: "تم تحديث الصلاحية بنجاح",
    users_new_password_label: "كلمة مرور جديدة",
    users_reset_pw_hint: "اتركه فارغًا لعدم التغيير",
    users_reset_pw_btn: "إعادة تعيين",
    users_reset_pw_ok: "تم تحديث كلمة المرور بنجاح",
    users_delete_btn: "حذف المستخدم",
    users_delete_confirm: "متأكد من الحذف؟",
    users_delete_ok: "تأكيد الحذف",

    chat_header: "💬 اسأل عن المخطط (محادثة تفاعلية)",
    chat_caption:
      "شغالة على نفس ملف الـ PDF اللي رفعته فوق من غير ما تحتاج ترفعه تاني — اسأل، صحّح، أو اطلب توضيح لحد ما توصل لنتيجة مرضية.",
    chat_template_label: "نوع السؤال",
    chat_template_custom: "✍️ سؤال حر",
    chat_template_materials: "🧮 احسب كميات المواد بتفاصيل معينة",
    chat_template_rooms: "📐 احسب قياسات الغرف",
    chat_template_element: "🔍 هل يوجد عنصر معين؟",
    chat_template_security: "🛡️ برومبت أمن مخصص (محطات محولات)",
    chat_template_fire: "🔥 برومبت حريق مخصص (TES-P-119.21)",
    chat_fire_hint:
      "هيتبعت للمودل قايمة متطلبات كشف وإطفاء الحريق الكاملة لكل مناطق المحطة حسب المواصفة، ويطلب منه يطلعلك جدول كميات بناءً على اللي موجود في المخطط.",
    chat_table_add_to_main: "➕ أضف للجدول الرئيسي",
    chat_table_added_ok: "✅ اتضاف للجدول الرئيسي",
    chat_template_materials_hint:
      "اكتب المواد/الأجهزة اللي عايز تحسبها بالتفصيل، سطر لكل عنصر.",
    chat_template_materials_placeholder: "1. كاشفات الدخان\n2. طفايات الحريق\n3. الرشاشات",
    chat_template_rooms_hint:
      "هيطلب من الموديل قياسات (الأبعاد والمساحات) كل الغرف الموجودة في المخطط.",
    chat_template_element_hint: "اسم العنصر/الجهاز اللي عايز تتأكد منه:",
    chat_template_element_placeholder: "مطفأة حريق CO2",
    chat_security_class_label: "نوع المحطة (Substation Class)",
    chat_security_prompt_label: "نوع البند المطلوب",
    chat_security_hint:
      "هيتبعت البرومبت التفصيلي الجاهز (زي المتفق عليه مع HCIS) للمودل كما هو، ويطلب منه يستخرج جدول كميات (BOQ) بناءً عليه.",
    chat_template_need_input: "⚠️ اكتب سؤالك أو املأ التفاصيل المطلوبة الأول.",
    chat_input_label: "اكتب سؤالك أو ملاحظتك",
    chat_placeholder: "مثلاً: طلعلي كل الديتكتورز في الدور التاني بس",
    chat_send: "📨 ابعت",
    chat_thinking: "بيفكر...",
    chat_needs_save: "لازم تحفظ التحليل في الأرشيف الأول عشان تقدر تبدأ محادثة.",
    chat_empty: "لسه مفيش أسئلة — ابدأ المحادثة من تحت.",

    rag_header: "📚 أضف كمرجع لمكتبة التعلم (RAG)",
    rag_caption:
      "هيتحفظ المخطط ده كمثال معتمد — التحليلات والمحادثات الجاية لنفس نوع النظام هتسترشد بيه تلقائيًا.",
    rag_correction_caveat:
      "⚠️ ملحوظة: الحفظ هيسجّل نتيجة التحليل الأوتوماتيكي الحالية كما هي. لو صححت حاجة في المحادثة فوق، التصحيح ده لسه مش بيترجع تلقائيًا للنتيجة المحفوظة — لو عايز المرجع يعكس التصحيح، حدّث الأرقام يدويًا الأول.",
    rag_tag_label: "تصنيف/وصف قصير للمخطط ده",
    rag_tag_placeholder: "مثلاً: مخطط فيلا سكنية - نظام إنذار حريق",
    rag_save_btn: "💾 احفظ كمرجع",
    rag_tag_required: "⚠️ اكتب تصنيف قصير للمخطط الأول.",
    rag_saved_ok: "✅ اتحفظ في مكتبة المراجع بنجاح.",

    projects_title: "📋 المشاريع",
    projects_subtitle:
      "ارفع مواصفة المشروع الفنية (PTS) واستخرج منها الخلاصة الفنية اللي محتاجها مهندس الكميات قبل ما يفتح أي مخطط — يعرف راسه من رجليه من أول خطوة.",
    projects_upload_label: "ملف مواصفة المشروع (PDF)",
    projects_upload_hint: "ملفات PDF بس. ممكن يكون المستند طويل (عشرات الصفحات) — استخراجه ممكن ياخد دقيقة أو أكتر.",
    projects_extract_btn: "📤 استخرج الخلاصة الفنية",
    projects_extracting: "جاري قراءة المستند كامل وتحليله... ممكن ياخد شوية وقت لو المستند طويل.",
    projects_extract_failed: "فشل استخراج الخلاصة.",
    projects_no_file: "⚠️ اختار ملف PDF الأول.",
    projects_extract_truncated_warning:
      "⚠️ الرد اتقطع لأنه وصل لأقصى طول مسموح به — المستند طويل جدًا. الأقسام اللي ظهرت فوق دي كاملة وصحيحة، لكن ممكن يكون في أقسام كمان ماوصلتش. راجع آخر أجزاء الملف يدويًا، أو جرب ترفعه على دفعات أصغر.",

    projects_digest_title: "الخلاصة الفنية",
    projects_section_title_ar: "اسم المستند",
    projects_section_systems: "الأنظمة المشمولة",
    projects_section_general_rules: "قواعد عامة / أولويات",
    projects_section_standards: "المواصفات القياسية المرجعية",
    projects_col_standard_code: "الكود",
    projects_col_standard_title: "الوصف",
    projects_section_scope: "نطاق العمل لكل نظام",
    projects_scope_key_requirements: "أهم المتطلبات",
    projects_scope_coverage_areas: "المناطق المشمولة",
    projects_section_design_criteria: "معايير التصميم",
    projects_col_parameter: "المعيار",
    projects_col_value: "القيمة",
    projects_col_reference: "المرجع",
    projects_section_equipment: "مواصفات المعدات",
    projects_col_item: "البند",
    projects_col_requirement: "المطلوب",
    projects_section_zone_tables: "جداول متطلبات المناطق",
    projects_col_zone: "المنطقة",
    projects_section_alarms: "ملخص الإنذارات والتشابكات",
    projects_col_alarm_system: "النظام",
    projects_col_alarm_points: "عدد نقاط الإنذار",
    projects_col_notable_alarms: "إنذارات بارزة",
    projects_section_commissioning: "اختبارات التشغيل",
    projects_section_submittals: "المستندات المطلوب تقديمها",
    projects_section_open_items: "⚠️ نقاط مفتوحة لمهندس الكميات",
    projects_empty_section: "لا يوجد.",

    projects_save_filename_label: "اسم الحفظ",
    projects_save_btn: "💾 احفظ المستند",
    projects_saved_ok: "✅ اتحفظ بنجاح.",
    projects_save_failed: "فشل الحفظ.",

    projects_saved_list_title: "المستندات المحفوظة",
    projects_saved_loading: "جاري التحميل...",
    projects_saved_empty: "لا توجد مستندات محفوظة بعد.",
    projects_view_btn: "عرض",
    projects_hide_btn: "إخفاء",
    projects_view_pdf_btn: "عرض PDF الأصلي",
    projects_delete_btn: "حذف",
    projects_delete_confirm: "متأكد من الحذف؟",
    projects_delete_ok: "تأكيد الحذف",

    projects_match_rooms_title: "🧪 تجربة: تحديد متطلبات كل غرفة من المخطط",
    projects_match_rooms_subtitle:
      "خطوة تجريبية أولى — ارفع مخطط حقيقي (PDF) وهنستخدم الخلاصة الفنية فوق عشان نحدد كل غرفة/منطقة في المخطط ونقول المطلوب فيها حسب المواصفة. الخطوات الجاية هنكمل تدريب الموديل عليها تباعًا.",
    projects_match_rooms_need_digest: "لازم تستخرج أو تفتح خلاصة فنية الأول عشان تقدر تجرب الخطوة دي.",
    projects_match_rooms_upload_label: "ملف المخطط (PDF)",
    projects_match_rooms_btn: "🔎 حدد متطلبات الغرف",
    projects_match_rooms_running: "جاري قراءة المخطط ومطابقته بالخلاصة الفنية...",
    projects_match_rooms_failed: "فشل تحليل المخطط.",
    projects_match_rooms_truncated_warning:
      "⚠️ الرد اتقطع لأنه وصل لأقصى طول مسموح به — لو المخطط كبير (صفحات كتير)، جرب ترفع جزء أصغر منه في المرة الواحدة.",
    projects_match_rooms_results_title: "نتيجة المطابقة",
    projects_col_room_name: "الغرفة/المنطقة",
    projects_col_room_matched: "التصنيف المطابق",
    projects_col_room_page: "الصفحة",
    projects_col_room_required: "الأنظمة المطلوبة",
    projects_col_room_notes: "ملاحظات",
    projects_match_rooms_unmatched: "غرف من غير تطابق واضح",
    projects_match_rooms_unseen: "بنود من الخلاصة مالهاش ظهور في المخطط",
    projects_match_rooms_notes: "ملاحظات عامة",
  },
  en: {
    brand_name: "AECO",
    brand_tagline: "Fire & Security AI Engine",
    login_title: "Sign in",
    login_subtitle: "Please sign in to continue",
    username: "Username",
    password: "Password",
    login_btn: "Sign in",
    login_failed: "Sign-in failed",
    logging_in: "Signing in...",
    nav_projects: "📋 Projects",
    nav_analyze: "🚀 Analyze New Drawing",
    nav_archive: "📁 Saved Sessions & Archive",
    nav_users: "👥 User Management",
    logout: "🚪 Logout",
    theme_dark: "🌙 Dark",
    theme_light: "☀️ Light",
    language_label: "Language",

    archive_title: "📁 Saved Sessions & Archive",
    archive_subtitle: "Browse previously saved analyses, rename or delete them.",
    archive_loading: "Loading...",
    archive_empty: "No saved sessions yet.",
    archive_view_btn: "View",
    archive_hide_btn: "Hide",
    archive_rename_btn: "Rename",
    archive_rename_save: "Save",
    archive_cancel: "Cancel",
    archive_delete_btn: "Delete",
    archive_delete_confirm: "Are you sure?",
    archive_delete_ok: "Confirm delete",
    archive_no_data: "No saved analysis data for this session.",

    users_title: "👥 User Management",
    users_subtitle: "Add new users, change roles, or reset passwords.",
    users_create_title: "Add a new user",
    users_create_btn: "Create user",
    users_create_ok: "User created successfully",
    users_list_title: "Existing users",
    users_list_empty: "No users found.",
    users_col_username: "Username",
    users_col_email: "Email",
    users_col_role: "Role",
    users_new_role_label: "New role",
    users_change_role_btn: "Update role",
    users_role_updated: "Role updated successfully",
    users_new_password_label: "New password",
    users_reset_pw_hint: "Leave blank to keep unchanged",
    users_reset_pw_btn: "Reset",
    users_reset_pw_ok: "Password updated successfully",
    users_delete_btn: "Delete user",
    users_delete_confirm: "Are you sure?",
    users_delete_ok: "Confirm delete",

    chat_header: "💬 Ask About This Drawing (Interactive Chat)",
    chat_caption:
      "Uses the same PDF you already uploaded above — no need to re-upload it. Ask, correct, or clarify until you're happy with the answer.",
    chat_template_label: "Question type",
    chat_template_custom: "✍️ Free-form question",
    chat_template_materials: "🧮 Calculate material quantities with details",
    chat_template_rooms: "📐 Calculate room dimensions",
    chat_template_element: "🔍 Check if an element exists",
    chat_template_security: "🛡️ Security BOQ Prompt (Substations)",
    chat_template_fire: "🔥 Fire Protection BOQ Prompt (TES-P-119.21)",
    chat_fire_hint:
      "Sends the model the full fire detection/protection requirements for every substation area per the standard, and asks it to produce a Bill of Quantities based on what's actually in the drawing.",
    chat_table_add_to_main: "➕ Add to main table",
    chat_table_added_ok: "✅ Added to main table",
    chat_template_materials_hint:
      "List the materials/devices you want quantities for, one per line.",
    chat_template_materials_placeholder: "1. Smoke detectors\n2. Fire extinguishers\n3. Sprinklers",
    chat_template_rooms_hint:
      "Asks the model for the dimensions (size and area) of every room in the drawing.",
    chat_template_element_hint: "Name of the element/device to check for:",
    chat_template_element_placeholder: "CO2 fire extinguisher",
    chat_security_class_label: "Substation Class",
    chat_security_prompt_label: "Prompt topic",
    chat_security_hint:
      "Sends the full prepared HCIS-style engineering prompt to the model as-is, and asks it to produce a Bill of Quantities based on it.",
    chat_template_need_input: "⚠️ Type your question or fill in the required details first.",
    chat_input_label: "Type your question or note",
    chat_placeholder: "e.g. List all the detectors on the second floor only",
    chat_send: "📨 Send",
    chat_thinking: "Thinking...",
    chat_needs_save: "Save this analysis to the archive first to start a conversation.",
    chat_empty: "No questions yet — start the conversation below.",

    rag_header: "📚 Save as a Reference (RAG Library)",
    rag_caption:
      "Saves this drawing as an approved example — future analyses and chats of the same system type will automatically be grounded in it.",
    rag_correction_caveat:
      "⚠️ Note: saving records the current automatic analysis result as-is. If you corrected something in the chat above, that correction is not yet reflected back into the saved result automatically — update the numbers manually first if you want the reference to reflect the correction.",
    rag_tag_label: "Short tag/description for this drawing",
    rag_tag_placeholder: "e.g. Residential villa - fire alarm system",
    rag_save_btn: "💾 Save as Reference",
    rag_tag_required: "⚠️ Type a short tag for the drawing first.",
    rag_saved_ok: "✅ Saved to the reference library successfully.",

    projects_title: "📋 Projects",
    projects_subtitle:
      "Upload the project's technical specification (PTS) and extract the technical digest the quantity engineer needs before opening any drawing — know the project inside out from step one.",
    projects_upload_label: "Project specification file (PDF)",
    projects_upload_hint: "PDF only. The document can be long (dozens of pages) — extraction may take a minute or more.",
    projects_extract_btn: "📤 Extract Technical Digest",
    projects_extracting: "Reading and analyzing the full document... this can take a while for a long document.",
    projects_extract_failed: "Failed to extract the digest.",
    projects_no_file: "⚠️ Choose a PDF file first.",
    projects_extract_truncated_warning:
      "⚠️ The response was cut off because it hit the maximum reply length — the document is very long. The sections shown above are complete and accurate, but some sections may be missing entirely. Review the last parts of the document manually, or try uploading it in smaller batches.",

    projects_digest_title: "Technical Digest",
    projects_section_title_ar: "Document title",
    projects_section_systems: "Systems covered",
    projects_section_general_rules: "General rules / precedence",
    projects_section_standards: "Applicable standards",
    projects_col_standard_code: "Code",
    projects_col_standard_title: "Title",
    projects_section_scope: "Scope of work per system",
    projects_scope_key_requirements: "Key requirements",
    projects_scope_coverage_areas: "Coverage areas",
    projects_section_design_criteria: "Design criteria",
    projects_col_parameter: "Parameter",
    projects_col_value: "Value",
    projects_col_reference: "Reference",
    projects_section_equipment: "Equipment specifications",
    projects_col_item: "Item",
    projects_col_requirement: "Requirement",
    projects_section_zone_tables: "Zone requirement tables",
    projects_col_zone: "Zone / area",
    projects_section_alarms: "Alarm & interlock summary",
    projects_col_alarm_system: "System",
    projects_col_alarm_points: "Total alarm points",
    projects_col_notable_alarms: "Notable alarms",
    projects_section_commissioning: "Commissioning tests",
    projects_section_submittals: "Submittals & annexures",
    projects_section_open_items: "⚠️ Open items for the estimator",
    projects_empty_section: "None.",

    projects_save_filename_label: "Save as",
    projects_save_btn: "💾 Save document",
    projects_saved_ok: "✅ Saved successfully.",
    projects_save_failed: "Failed to save.",

    projects_saved_list_title: "Saved documents",
    projects_saved_loading: "Loading...",
    projects_saved_empty: "No saved documents yet.",
    projects_view_btn: "View",
    projects_hide_btn: "Hide",
    projects_view_pdf_btn: "View original PDF",
    projects_delete_btn: "Delete",
    projects_delete_confirm: "Are you sure?",
    projects_delete_ok: "Confirm delete",

    projects_match_rooms_title: "🧪 Trial: identify each room's requirements from a drawing",
    projects_match_rooms_subtitle:
      "An initial trial step — upload a real drawing (PDF) and we'll use the technical digest above to identify every room/area on it and state what's required per the spec. We'll keep training the model on the remaining steps next.",
    projects_match_rooms_need_digest: "Extract or open a technical digest first to try this step.",
    projects_match_rooms_upload_label: "Drawing file (PDF)",
    projects_match_rooms_btn: "🔎 Identify room requirements",
    projects_match_rooms_running: "Reading the drawing and matching it against the digest...",
    projects_match_rooms_failed: "Failed to analyze the drawing.",
    projects_match_rooms_truncated_warning:
      "⚠️ The response was cut off because it hit the maximum reply length — if the drawing has many pages, try uploading a smaller part of it at a time.",
    projects_match_rooms_results_title: "Matching results",
    projects_col_room_name: "Room / area",
    projects_col_room_matched: "Matched category",
    projects_col_room_page: "Page",
    projects_col_room_required: "Required systems",
    projects_col_room_notes: "Notes",
    projects_match_rooms_unmatched: "Rooms with no clear match",
    projects_match_rooms_unseen: "Digest categories not seen in the drawing",
    projects_match_rooms_notes: "General notes",
  },
} as const;

export type Lang = keyof typeof translations;
export type TranslationKey = keyof (typeof translations)["en"];

type I18nState = {
  lang: Lang;
  setLang: (lang: Lang) => void;
};

const STORAGE_KEY = "aeco_lang";

// Always "ar" for this store's very first value — on BOTH the server
// render and the client's initial render before hydration. This file has
// no true SSR/CSR split (it's a "use client" module instantiated fresh in
// each environment), so the old version — returning `window ? stored :
// "ar"` — made the server always produce "ar"-language HTML while a
// returning client with lang="en" saved would instantiate this same
// store with "en" *before* React had hydrated against the server HTML.
// That's a text-content mismatch on every single translated string on
// the page at once, which is exactly what was surfacing as React's
// minified hydration error #418 and taking the whole app down to a
// blank screen with no other clue. The actual persisted language is
// applied a tick later instead, via hydrateLangFromStorage() below,
// called from a client-only useEffect (see providers.tsx) — a normal
// post-hydration state update, not part of the hydration diff, so it
// can safely differ from the first render.
function readInitialLang(): Lang {
  return "ar";
}

export const useI18nStore = create<I18nState>((set) => ({
  lang: readInitialLang(),
  setLang: (lang) => {
    if (typeof window !== "undefined") window.localStorage.setItem(STORAGE_KEY, lang);
    set({ lang });
  },
}));

/** Applies whatever language was actually persisted from a previous
 * visit. Must only ever run client-side, after the first paint — see the
 * comment on readInitialLang() above for why. */
export function hydrateLangFromStorage() {
  if (typeof window === "undefined") return;
  const stored = window.localStorage.getItem(STORAGE_KEY);
  if (stored === "en" || stored === "ar") {
    useI18nStore.setState({ lang: stored });
  }
}

export function dirFor(lang: Lang) {
  return lang === "ar" ? "rtl" : "ltr";
}

/** `const t = useT()` then `t.login_title` — mirrors the Streamlit code's
 * `t = TRANSLATIONS[lang_code]; t["login_title"]` usage closely enough
 * that porting a screen's strings over is mostly mechanical. */
export function useT() {
  const lang = useI18nStore((s) => s.lang);
  return translations[lang];
}
